<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<!-- Mulai Footer-->
<div class="container-bottom-footer" style="background-color: #66CCFF;">
            <div class="container">

              <!-- <h5 class="navbar-brand text-white" style="text-align: start;">TravelinKuy</h5> -->

              <div class="row row-cols-1 row-cols-md-4 g-4">
                
                <div class="col">
                  <div class="card h-100" style="background-color: transparent; border: none;">
                    <div class="card-body">
                      <center>
                      <h3>Logo GEDE</h3>
                      <a href="../travelinkuy/z-tips-melakukan-pemesanan.html">Logo</a>
                      <br>
                      <a href="../travelinkuy/z-Tips-Memilih-Destinasi.html">Logo</a>
                      <br>
                      <a href="../travelinkuy/z-Tips Hemat Saat Berpergian.html">Logo</a>
                      <br>
                      <a href="../travelinkuy/z-Berpergian-dengan-Aman.html">Logo</a>
                      <br>
                      <a href="../travelinkuy/tos/">Logo</a>
                      </center>
                    </div>
                  </div>
                </div>
                <div class="col">
                  <div class="card h-100" style="background-color: transparent; border: none;">
                    <div class="card-body">
                      
                      <h3>Tentang Kami</h3>
                      <p class="card-text" style="font-size: 14px; color: black;">Semua destinasi Wisata dalam satu Aplikasi Website.
                        Kini Hadir!<br>Setia memadu anda dalam wisata kemana saja.
                        TravelinSkuy adalah aplikasi website yang menyediakan informasi untuk setiap perjalanan destinasi anda. Kami menyediakan banyak destinasi yang menarik dan terbaik dari setiap daerah di indonesia. Yuk Jalan Jalan Bareng TravelinSkuyyy
                      </p>
                    </div>
                  </div>
                </div>
                <div class="col">
                  <div class="card h-100" style="background-color: transparent; border: none;">
                    <div class="card-body">
                      <h3>Tentang Kami</h3>
                      <p class="card-text"  style="font-size: 14px; color: black;">Semua destinasi Wisata dalam satu Aplikasi Website.
                        Kini Hadir!<br>Setia memadu anda dalam wisata kemana saja.
                        TravelinSkuy adalah aplikasi website yang menyediakan informasi untuk setiap perjalanan destinasi anda. Kami menyediakan banyak destinasi yang menarik dan terbaik dari setiap daerah di indonesia. Yuk Jalan Jalan Bareng TravelinSkuyyy
                      </p>
                    </div>
                  </div>
                </div>
                <div class="col">
                  <div class="card h-100" style="background-color: transparent; border: none;">
                    <div class="card-body">
                      <center>
                      <h3>Hubungi Kami</h3>
                      <br>
                      
                      <a href="http://"><button type="button" class="btn btn-outline-success">Whatsapp</button></a>
                      <br>
                      <br>
                      <a href="http://"><button type="button" class="btn btn-outline-primary">Facebook</button></a>
                      <br>
                      <br>
                      <a href="http://"><button type="button" class="btn btn-outline-light">instagram</button></a>
                    </center>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
</div></center>
<div class="card h-100" style="background-color: #66CCFF; border: none;">
      <center><p style="color:white;">Copyright © 2021 Travelin'sKuy</p></center>
</div>
<!-- Selesai Footer-->


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>

    <!-- Bothelp.io widget -->
    <script type="text/javascript">!function(){var e={"buttons":[{"type":"whatsapp","token":"081290053660"},{"type":"messenger","token":"http://fb.com/rizkiagungsx"},{"type":"instagram","token":"rizkiagung.id"}],"color":"#599AF0","position":"right","bottomSpacing":"","callToActionMessage":"Message Us","displayOn":"everywhere","lang":"en"},t=document.location.protocol+"//bothelp.io",o=document.createElement("script");o.type="text/javascript",o.async=!0,o.src=t+"/widget-folder/widget-page.js",o.onload=function(){new BhWidgetPage.init(e)};var n=document.getElementsByTagName("script")[0];n.parentNode.insertBefore(o,n)}();</script>
<!-- /Bothelp.io widget -->
  </body>
</html>